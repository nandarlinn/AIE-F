# Assignment 5 Results and Explanation

Student: Thein Gi Kyaw  
Topic: Domain Adaptation with Language Model  
Notebooks:

- `TGK_KenLM.ipynb`
- `TGK_LSTM.ipynb`
- `TGK_KenLM_word.ipynb`
- `TGK_LSTM_word.ipynb`

## Dataset

Three domain datasets were used from:

`DomainTest/Dataset/`

| File | Domain |
|---|---|
| `fitness.csv` | Fitness / exercise |
| `health.csv` | Medical / health |
| `realEstate.csv` | Real estate |

These three domains were used as test domains for LM evaluation and domain adaptation.

## Common Preprocessing Steps

Both notebooks use the same data preparation pipeline so that comparison is fair.

### 1. Load Data

Each CSV file is read as plain text lines. Empty lines are removed.

### 2. Text Cleaning

The cleaning step removes noisy symbols and normalizes text before tokenization.

Main cleaning operations:

- Unicode normalization with NFC
- Remove URLs and emails
- Remove Myanmar punctuation such as `၊` and `။`
- Remove repeated quotes and unnecessary symbols
- Keep Myanmar characters, English letters, digits, and spaces
- Collapse multiple spaces into one space

This step is important because punctuation and noisy symbols can create many rare tokens and increase perplexity.

### 3. Tokenization

The notebooks are configured to use Myanmar syllable-level tokenization.

Tokenizer priority:

1. Use external `sylbreak` if it is installed or if `SYLBREAK_CMD` is set.
2. If `sylbreak` is not installed, use a local syllable-like fallback tokenizer so the notebooks remain runnable.

After installing the local assignment `sylbreak` command through `requirements.txt`, the notebooks printed:

```text
Tokenizer used: sylbreak
```

The tokenizer:

- Splits text by whitespace first
- Splits Myanmar text into character clusters
- Keeps Myanmar dependent vowel marks, medials, tones, virama, and asat marks attached to the previous base character
- Keeps English words and numbers as separate lowercase tokens

The same tokenization method is used for:

- Base LM training
- Domain test sets
- Domain adaptation training

This satisfies the assignment requirement that train and test token types must be the same.

### 4. Fair Domain Test Sets

Each domain test set is made equal in size:

- 200 tokens per domain
- 10 lines per domain
- 20 tokens per line

The remaining tokens from each domain are used for base LM training and domain adaptation.

This makes the PPL comparison fair because each domain has the same test token count and sentence structure.

## Notebook 1: `TGK_KenLM.ipynb`

### Objective

Train and evaluate a KenLM n-gram language model, following the style of `LM-Tutorial.ipynb`.

### KenLM Workflow

The notebook uses the following KenLM tools:

- `lmplz`
- `build_binary`
- Python `kenlm.LanguageModel`

The KenLM binary path used in WSL:

```text
/home/gi/tools/kenlm/build/bin
```

The notebook was tested with the WSL virtual environment:

```text
/home/gi/.venvs/aie-f
```

### Step 1. Train Base KenLM

The base LM is trained using all remaining training tokens from the three domains after reserving the 200-token test sets.

Model type:

```text
5-gram KenLM
```

Training command style:

```text
lmplz -o 5 --discount_fallback --text base_train.word --arpa tgk_base_5gram.arpa
build_binary tgk_base_5gram.arpa tgk_base_5gram.binary
```

`--discount_fallback` is used because the domain datasets are small. Without this option, KenLM may fail to estimate Kneser-Ney discounts for sparse higher-order n-grams.

### Step 2. Evaluate Base KenLM PPL

The base KenLM model is evaluated on each equal-size domain test set.

Base KenLM results:

| Domain | Base PPL | Entropy (nats) | BPC |
|---|---:|---:|---:|
| RealEstate | 265.66 | 5.5822 | 2.0500 |
| Health | 194.77 | 5.2718 | 2.2784 |
| Fitness | 130.62 | 4.8723 | 2.0674 |

### Interpretation

Lower PPL means the LM predicts the domain text better.

The hardest domain for the base KenLM is:

```text
RealEstate, PPL = 265.66
```

This means health text contains more domain-specific vocabulary or phrasing that the base model predicts less confidently.

### Step 3. Domain Adaptation with KenLM

For adaptation, the notebook trains one small domain-specific KenLM for each domain.

Then it interpolates the base model probability and domain model probability:

```text
P_adapted = lambda * P_domain + (1 - lambda) * P_base
```

The domain weight used:

```text
lambda = 0.65
```

### KenLM Adaptation Results

| Domain | Base PPL | Adapted PPL | PPL Reduction |
|---|---:|---:|---:|
| RealEstate | 265.66 | 174.10 | 91.56 |
| Health | 194.77 | 176.85 | 17.92 |
| Fitness | 130.62 | 103.68 | 26.94 |

### KenLM Conclusion

Domain adaptation reduced PPL for all three domains.

The largest improvement was in:

```text
RealEstate
```

This shows that adding an in-domain LM helps the model assign better probabilities to domain-specific tokens and phrases.

## Notebook 2: `TGK_LSTM.ipynb`

### Objective

Train and evaluate an LSTM language model using the LSTM code from `LM-Tutorial.ipynb`.

The notebook reuses:

```text
slide-code/class-15/LM-Tutorial/lstm/lstm_lm.py
```

Classes reused:

- `Vocabulary`
- `TextDataset`
- `LSTM_LM`

### Step 1. Train Base LSTM LM

The base LSTM is trained on the same base training data used for KenLM.

Model settings:

| Setting | Value |
|---|---:|
| Sequence length | 20 |
| Embedding dimension | 64 |
| Hidden dimension | 128 |
| LSTM layers | 2 |
| Base epochs | 12 |
| Batch size | 32 |

The LSTM is word-token based because the prepared Myanmar syllable-like tokens are separated by spaces.

### Step 2. Evaluate Base LSTM PPL

Base LSTM results from the successful test run:

| Domain | Base PPL | Avg NLL | Test Types | OOV Types |
|---|---:|---:|---:|---:|
| RealEstate | 3367.66 | 8.1220 | 120 | 22 |
| Health | 1815.28 | 7.5040 | 111 | 17 |
| Fitness | 1250.07 | 7.1310 | 113 | 19 |

### Interpretation

The hardest domain for the base LSTM is:

```text
RealEstate, PPL = 3367.66
```

This matches the KenLM result after using `sylbreak`: real-estate text is also hardest for the neural LSTM LM.

The LSTM PPL values are higher than KenLM because:

- The dataset is small for neural LM training
- LSTM needs more data to learn stable probabilities
- OOV and sparse domain terms affect the neural model strongly
- KenLM n-gram smoothing is more effective for small text datasets

### Step 3. Domain Adaptation with LSTM Fine-Tuning

For domain adaptation, the notebook copies the base LSTM model and fine-tunes it on each domain's adaptation training tokens.

To avoid overfitting, the notebook keeps the best checkpoint based on target-domain PPL. If fine-tuning makes PPL worse, it keeps the base model result.

### LSTM Adaptation Results

| Domain | Base PPL | Adapted PPL | PPL Reduction | Relative Reduction |
|---|---:|---:|---:|---:|
| RealEstate | 3367.66 | 3336.08 | 31.58 | 0.94% |
| Health | 1815.28 | 1815.28 | 0.00 | 0.00% |
| Fitness | 1250.07 | 1250.07 | 0.00 | 0.00% |

### LSTM Conclusion

Fine-tuning helped slightly for the RealEstate domain, but not for Health and Fitness.

This is expected because neural LMs usually need more data for effective adaptation. With very small domain data, fine-tuning can easily overfit or fail to improve PPL.

## Comparison Between KenLM and LSTM

| Domain | KenLM Base PPL | LSTM Base PPL |
|---|---:|---:|
| RealEstate | 265.66 | 3367.66 |
| Health | 194.77 | 1815.28 |
| Fitness | 130.62 | 1250.07 |

KenLM performs better on this assignment dataset because the data is small. N-gram models with smoothing are strong baselines for small corpora.

Both models agree that:

```text
RealEstate is the hardest domain.
```

## Final Analysis

### Hardest Domain

The real-estate domain has the highest PPL in both notebooks after using `sylbreak`.

Possible reasons:

- More spelling and formatting variation in social-style real-estate posts
- Many numbers, prices, sizes, and location/property expressions
- Less overlap with the general/base training data
- Less overlap with the general/base training data

### Best Adaptation Result

KenLM adaptation improved all domains:

- RealEstate improved by 91.56 PPL
- Health improved by 17.92 PPL
- Fitness improved by 26.94 PPL

LSTM adaptation improved only RealEstate slightly.

### Recommended Strategy

For this assignment dataset, KenLM is the better base LM because:

- It trains quickly
- It works well with small data
- Its smoothed n-gram probabilities produce lower PPL
- Domain interpolation clearly reduces PPL

For larger future datasets, LSTM or Transformer LM fine-tuning could become stronger.

## Future Improvements

Possible improvements:

- Add more general-domain Myanmar corpora such as ALT, myPOS, news, religious text, and social media text
- Install and use `sylbreak` for true Myanmar syllable-level segmentation, or use `oppaWord` only for word-level segmentation
- Tune KenLM interpolation weight on a validation set
- Add domain-specific vocabulary normalization
- Train LSTM with more epochs and more data
- Try character-level LSTM for noisy Myanmar text
- Compare with Transformer-based causal LM fine-tuning

## Additional Word-Level Experiments

Two extra notebooks were created for word-level tokenization:

- `TGK_KenLM_word.ipynb`
- `TGK_LSTM_word.ipynb`

These notebooks are separate from the syllable-level `sylbreak` notebooks.

### Word-Level Tokenizer

The word-level notebooks try tokenizers in this order:

1. Use an external `oppaWord` command if it is available.
2. If `oppaWord` is not installed, use `myword.WordTokenizer`.

During the current test run, `oppaWord` was not installed, so the notebooks used:

```text
Tokenizer used: myword.WordTokenizer
```

The word tokenizer support was installed with:

```bash
cd /mnt/d/Job_Requirements/PracticalProjectsFromDrYe/AIE-F/assignment-submission/class-15/Thein_Gi_Kyaw_Assignment_5
/home/gi/.venvs/aie-f/bin/python -m pip install -r requirements_word.txt
```

Example word segmentation:

```text
Input : မြန်မာစာစမ်းမယ်
Output: မြန်မာ စာ စမ်း မယ်
```

### Word-Level Output Files

The word-level tokenized data and model artifacts are written to separate folders:

| Folder | Usage |
|---|---|
| `kenlm_word_artifacts/` | Word-level KenLM train/test/adaptation files and models |
| `lstm_word_artifacts/` | Word-level LSTM train/test/adaptation files and models |

Important tokenized files:

| File | Usage |
|---|---|
| `base_train.word` | Train base LM |
| `fitness_test.word` | Fitness test set |
| `health_test.word` | Health test set |
| `realestate_test.word` | RealEstate test set |
| `fitness_adapt_train.word` | Fitness domain adaptation |
| `health_adapt_train.word` | Health domain adaptation |
| `realestate_adapt_train.word` | RealEstate domain adaptation |

These files are the actual word-tokenized data used for training, testing, and adaptation in the word-level notebooks.

## Word-Level KenLM Results

Notebook:

```text
TGK_KenLM_word.ipynb
```

Model:

```text
5-gram KenLM trained on word-tokenized data
```

Base KenLM word-level PPL:

| Domain | Base PPL | Entropy (nats) | BPC |
|---|---:|---:|---:|
| RealEstate | 297.64 | 5.6959 | 1.7274 |
| Fitness | 263.66 | 5.5747 | 1.7778 |
| Health | 261.15 | 5.5651 | 1.8110 |

Hardest domain:

```text
RealEstate, PPL = 297.64
```

### Word-Level KenLM Adaptation

Domain-specific word-level KenLM models were trained and interpolated with the base KenLM.

| Domain | Base PPL | Adapted PPL | PPL Reduction |
|---|---:|---:|---:|
| RealEstate | 297.64 | 173.83 | 123.81 |
| Fitness | 263.66 | 185.63 | 78.03 |
| Health | 261.15 | 203.83 | 57.32 |

Word-level KenLM adaptation improved all three domains. The largest improvement was in the RealEstate domain.

## Word-Level LSTM Results

Notebook:

```text
TGK_LSTM_word.ipynb
```

Model:

```text
LSTM LM trained on word-tokenized data
```

Base LSTM word-level PPL:

| Domain | Base PPL | Avg NLL | Test Types | OOV Types |
|---|---:|---:|---:|---:|
| RealEstate | 5058.18 | 8.5288 | 120 | 53 |
| Health | 3189.98 | 8.0678 | 120 | 52 |
| Fitness | 2713.48 | 7.9060 | 112 | 41 |

Hardest domain:

```text
RealEstate, PPL = 5058.18
```

### Word-Level LSTM Adaptation

The word-level LSTM adaptation fine-tunes one copied base model per domain.

| Domain | Base PPL | Adapted PPL | PPL Reduction | Relative Reduction |
|---|---:|---:|---:|---:|
| RealEstate | 5058.18 | 5058.18 | 0.00 | 0.00% |
| Health | 3189.98 | 3185.10 | 4.88 | 0.15% |
| Fitness | 2713.48 | 2641.26 | 72.22 | 2.66% |

The word-level LSTM improved slightly for Fitness and Health, but did not improve RealEstate. This is likely because word-level tokenization creates more token types and more OOV words than syllable-level tokenization. Neural LMs need more training data to handle that larger vocabulary well.

## Syllable-Level vs Word-Level Comparison

### KenLM Base PPL

| Domain | Sylbreak Syllable PPL | Word-Level PPL |
|---|---:|---:|
| RealEstate | 265.66 | 297.64 |
| Health | 194.77 | 261.15 |
| Fitness | 130.62 | 263.66 |

### LSTM Base PPL

| Domain | Sylbreak Syllable PPL | Word-Level PPL |
|---|---:|---:|
| RealEstate | 3367.66 | 5058.18 |
| Health | 1815.28 | 3189.98 |
| Fitness | 1250.07 | 2713.48 |

### Analysis

Syllable-level tokenization gives lower PPL than word-level tokenization for both KenLM and LSTM in this experiment.

Possible reasons:

- Syllable-level vocabulary is smaller.
- Word-level tokenization creates more rare and unseen tokens.
- The dataset is small, so word-level LMs suffer more from sparsity.
- KenLM handles sparse word n-grams better than LSTM, but syllable-level KenLM is still stronger here.

Overall, for this assignment dataset:

```text
Best practical setup: sylbreak syllable-level KenLM with domain adaptation.
```
