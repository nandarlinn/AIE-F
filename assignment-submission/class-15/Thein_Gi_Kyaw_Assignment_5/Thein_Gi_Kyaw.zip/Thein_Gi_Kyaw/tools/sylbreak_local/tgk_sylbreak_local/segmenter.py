import re

MY_CONSONANT = "\u1000-\u1021"
EN_CHAR = "a-zA-Z0-9"
OTHER_CHAR = "\u1023\u1024\u1025\u1026\u1027\u1029\u102A\u103F\u104C\u104D\u104E\u1040-\u1049\u104A\u104B!-/:-@\\[-`{-~\\s"
SS_SYMBOL = "\u1039"
A_THAT = "\u103A"

SYLBREAK_RE = re.compile(
    rf"((?<![{SS_SYMBOL}])[{MY_CONSONANT}](?![{A_THAT}{SS_SYMBOL}])|[{EN_CHAR}{OTHER_CHAR}])"
)


def syllable_segment(text: str, separator: str = " ") -> str:
    """Segment Myanmar text with the sylbreak regular-expression rule."""
    return SYLBREAK_RE.sub(rf"{separator}\1", text).strip()

