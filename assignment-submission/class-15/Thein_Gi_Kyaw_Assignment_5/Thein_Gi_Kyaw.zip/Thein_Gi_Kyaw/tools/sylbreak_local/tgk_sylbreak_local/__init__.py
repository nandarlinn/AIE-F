from .segmenter import syllable_segment

__all__ = ["syllable_segment"]

