import argparse
import sys

from .segmenter import syllable_segment


def main() -> int:
    parser = argparse.ArgumentParser(description="Myanmar syllable segmentation using the sylbreak RE rule.")
    parser.add_argument("-s", "--separator", default=" ", help="Syllable separator. Default: space.")
    args = parser.parse_args()

    for line in sys.stdin:
        print(syllable_segment(line.rstrip("\n"), separator=args.separator))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

