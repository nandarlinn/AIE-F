te' te' pjaun 
ka' pi. 
shoun. me. 
njhin: ban: 
mun: man 
nge me 
sha sha hpwei hpwei 
pa: bjin: 
u. ma- kwe: thai' ma- pje' 
a- si' 
jei kya. 
ma- hsou' ma- hsain: 
ha kwe' 
mein: mu: 
ke ma. 
nin: ne 
ka. gyou: tan za 
hsun: gyi: laun: 
wa kyin. gyin. 
kou' hi: na 
ni kyin gyin 
a- lou du 
kein: jin: 
mi: dain 
wei. le kyaun pa' 
za- ga: pjo: kyi: nan: 
a- chi' u: 
a- the: kaun: 
nja. gyi: 
chou mja. mja. 
mju mhe' 
hsei: bo 
a- ke jwei. 
a- lai' kan: hsou: ma- thi. 
je: be' 
a- khan zei: 
gwa. kwe' 
tha- lin: daun 
a- kyaun: mu ga: 
a dhi: 
ei: da- mja. 
mhi we: 
pein ဍတ် hta. 
ke' ta- lau' 
hpa. gin 
gyo. gyan: 
kaun: za: 
jan: than: 
swe: hsou 
ka' pa: 
tou tou htwa htwa 
khain loun 
shwei hsain: 
jou' wa da. 
pu. dou 
pwin. lan: 
mje' hsan gye 
thou: hti: 
hpau' chi 
ta' hsin 
ja dhi u. du. 
a- gya: ka' 
ka- la- hsin 
a- sei. she' 
kun: daun kain 
da' dhwa: 
khin: nhi: 
laun: taun: 
me' kun 
a- maun 
nau' pjaun 
bou kei 
jei gye' ei: 
kyin bo 
sa bjin 
lei gyo: 
jaun pju. dha- lwin 
mje' nha- ke: 
a- kha lun 
a- nhou' le' kha- na 
si man gein: 
ja. nou: 
njhou: nge 
jwe' tai' 
moun. moun. nje' nje' 
khwei: lhei: ja: 
htu: dwin: 
lin ban: 
ta' ta' swe: 
sa- mjin 
pji pa. 
khwei: ju: 
ba wa. jou' 
na ra- ni 
a ma. gan pji' si: 
chu: dhu 
kan: mjaun dei tha. 
gyei le 
hpa- ja: 
jin ma- me: jain: 
la' sa: 
mwei: je' 
ke laun: 
nga- hpoun: hsei: 
pe: hsi 
sa kyan mha' 
pa- rou tin: 
an da- je 
a- chi' do 
lo: hso 
dha- din: thoun: hpo 
tha- jan za ta. 
mjau' lou' 
sa si sa goun: 
pji' zoun 
pei tan 
a- mja' to gun 
mou: jei gan thin gan: 
a- kyo: hta. 
kya' ngan jei 
a- kya' 
lun: kyin 
a- hte pje' 
hpja' pain: 
ou: ein htu 
le' kha- sa: na: 
gan ta' 
u. hpaun: 
kein: gan: 
bjan tan dan nan. tan. dan. 
mi: bwin. dhwa: 
jei ngin 
maun nhan 
le' thwei: 
jan: လွေ့ 
chei' pei' tin da 
ja hu. daun. 
ga- bwi: 
hpjau' hsei' mje' nha thi' 
nhi' chin: min ga- la 
a- hsi ji' 
a- khin: dhwa: 
lo: gu' lou' 
le kwe' 
a- nei' sa. 
in: ga- tha- ma. ou' sa 
u. pa- ma a- lin ga 
ga- dou: 
a ha ra. 
jwe su: 
jei: ja 
a- sou. bau' 
sho: saun 
pin le zoun: 
a- sa tin 
hpoun boun 
thwei: hsa 
ein ja mha: 
mji' twei: 
lu jou thei shin jou thei 
be do. 
a- ja' be' 
a- tou a- sa. 
shin ma. 
shein so 
da- bu' 
pe: da- le' 
lei lan pji' 
pwe: tou: 
be' ga- la 
maun: njou 
rei di jou te li sa- gou' 
hsa- lan pei: 
thi: hpja: hpu' 
na- daun: gyou: 
na- ga- ba ji 
shai' kyi: ngin gyi: 
a- shun: 
a ri. jan 
lu jei: pja. 
na- lin pjan 
sa- khan: dhwa: 
nha nu. 
ga- hei hse' 
le' ma. 
wa- lin 
nhi' ရှောင့် nhi' sha: 
o le: 
kye' tu jwei: 
tha' pou' 
a- pje' a- zi: 
ou: htein: dhe 
lei hpan: dan: zi: 
dwei: bo 
ki. lei' hta. do: dha. 
au' chei 
ku: than: 
ဂြိုလ် kya. 
kha: kha: thi: dhi: 
hpwin. lhi' 
hsa' ko. la' ko. 
mou' dain 
lei. la 
mje' nha- do hpwin. 
le si: gyou: 
kyo nja 
chan: ei: 
thu gaun: 
nga- hpe aun: 
du. pjin 
kha- no ni kha- no ne. 
mi: kwe' na 
hpwa: mjin 
pa- njaun 
koun ja- hta: 
hta- nje' 
ei' me' pei: 
tha- chin: khan 
mjou. thein: ta' 
se' bi: 
hpau' dan 
twei: loun: 
a- tan: bain hsa- ja 
na- kan na 
ma- ja- man 
u: htou' gyou: 
a- kye gyou' 
taun ga- ban: 
a- jei' ta- gyi. kyi. 
kyan. gyan. khan 
ba- doun: 
pa- lu bjan 
ga- ja 
a- ji: gyi: 
khi' shei. bjei: 
moun. kya khwe' 
tain: mhu: 
pan: daun: le 
a- pjin ba- wo: 
lan: u: tai' 
htu' ain: na 
jwe' hte 
nwa: nau' 
tha: gyi: ma- ja: gyi: 
le' dou 
ou' sa 
le bo pei: 
zei: gyou' 
da' lhei ga: 
chei pji' le' pji' 
e' kha- ja thin cha 
tu' ti: du' ta pjo: 
hpaun za: 
pa- la ja 
bei: ban: 
jei paun 
mi: kha' 
hse li kyei 
pou' ma. 
shein: shein: 
jin boun dha: 
nan hpe' 
ka- za' 
ta wun khan 
du. ne. dei: 
ba- ga- di. pa- ma na. 
a bau' 
a- lu' hpjei 
na- poun: lein 
dha- bjei njou jaun 
ou za- na 
da- ma. 
mje' jei le jwe: 
kyoun za: 
kin: ma- le' me: 
khwa pja 
si' pjan 
sa- tou' hta. 
nge kyun 
lau' thei 
hsau' khau' 
a- mje' 
ei. tha mi' hsa- ri. ja. 
jei jwe' 
sa- jin: shin 
gyo. shin: 
ရှောင်း ရှောင်း 
a- lun a- kyun 
mje' mhau' 
pjei pja' 
ma- ja: 
no za ban: 
ja. hain: 
pa- lou' kyin: 
a: tin: 
hsun: khan 
ba- la bwe: 
ba- zun chei kywei 
tha: gyi: o: ra. tha. 
mi: ou' hsaun: 
a- nain lu. 
pou: laun: 
si: ka- je' 
lu mai' 
nei htwe' ta- pju 
mjin: pji' 
ei: chan: 
pju: ka- lu: bja ga- la 
a- jaun jaun a- mha: mha: 
a- kyan ai' 
a- hswe 
ji' na' 
a- pjain: a- jain: 
lhwa. hswe: 
htou: dha: 
shei: hpoun: shei: kan 
ga- dein: ga- ba: hpji' 
nha' hswe: bu: 
kha- ji: kha- tin: 
pja' tau' pja' tau' 
a- ljau' ba dha 
a- chein shi. 
pan: zoun dha: 
ja- khu. na. 
ein me' me' 
chin. wun 
gin: ga 
khwe: cha: 
mein: ma- mhu. 
ga hta 
nji. ne' 
thwei: pjaun: 
kha- ji: hpin. 
than hsoun 
chin: ja 
a- jin: a- cha 
ti: tou: pjo: 
jei da- jau' 
a- dei' be kau' 
za- la: 
an: pji: nan: pji: 
dha- din: mei: 
ki lou mi ta 
wu' hsan hte. 
lei te' 
tha- ma. bain: 
a chau' 
le' kha- 
wu' ju' zin 
thwe' cha pa to: le 
pjan. pjan. jan. jan. 
jai' gye' 
a- hpou: chou 
pjein: mje' 
hse' sa' 
min: bau' 
the' ma- cha. 
le' wa: saun: khou' 
lu' ja kyu' ja 
a- dun. shei 
le' pjan gyou: tou' 
a- houn 
mje' nha- hta: 
sun thou' 
htun: htun: pau' pau' hpji' 
kan. gyou' 
sa dan: 
jin: mji' 
ou ba dain 
tha' in: 
gwa. dou 
ein daun dhe 
ta- ja: dhu gyi: 
tha la- ka 
pan gya: 
a- khwin. 
hsou' jou' 
thi' khe' de: 
da- ni. ta. e' kha- ja 
hou' la: 
mjin gwin: gye 
thi' to: 
lan: pwin. 
a- tou gyou' 
sin ne' kha' 
mje' ge: kha' 
lei' pja zin 
than tho. 
ma- wu' ja. da' 
hpjin po: 
hti: di: gyi: 
na- ji: si: 
pa- hsou' pa- ni 
za' koun hpwin. 
jou: hse' 
mhan ba. 
ta- sein. zein. 
nei win jou: ri 
chau' ka' 
da- lha' 
wun: dwin: gau' 
kyaun ba: 
mai' sa. toun: 
pei an. 
hsi: chou' jo: ga 
tha- mi: jau' kha- ma. 
kyei: tai' 
thain: kwe' 
poun: shou: 
kyei na' 
jau' ja pau' ja 
thoun: ze. ta- boun 
le' soun mou: 
le' lou' le' sa: 
lin: bain 
ta- hpe' lhe. 
nein. ba: 
hpjoun: kyau' 
ta- jau' ta- bau' 
a- hpau' 
ဘဒ် da. ga- ba 
ne shin pe shin 
da' hsi in gyin 
ja khin: 
twei wei 
oun: zan gyou: 
ba- da: 
hsei: chau' 
wa- na 
ma- ka. 
loun: gyi: pau' lha. 
zi: kwe' 
thin ni: mha' che' 
ka' nji. 
ta' hpjau' 
a- chin dhei' 
kyau' zein: 
a- khun a- tou' 
mje' hsa. 
a- li' thou' 
san gyein tin 
le' hsa. 
nga- sa' saun 
jei mjaun: 
ma- shu. ma- lha. 
za- ga: sa. mji pjo: 
thi la. kaun: 
win: bau' 
a- htein: do 
kwe' kwe' gwin: gwin: 
di zin ba 
a- bi 
hpjei hse 
ba tho: nja dho: 
the' mwei: wan: gyaun: pjin nja 
sa: kein: 
bjaun kwe 
kyei' hsoun 
jwa hsou: koun: 
da- zu. 
man da li 
gaun: khan 
le' dou. 
shwei din: ga: kye' 
toun: loun: lhe: 
lu zu. khwe: 
jei la mjaun: pei: 
kyei: jwa ou' su. 
to: mhau' 
than kun cha 
jou: jou: mha' mha' 
pwe: u: htwe' 
hsi: kyou 
e. wu' 
hsin hsa 
a- lhwa a- lhwa 
moun. gyu' 
a- shin 
pji: pja' 
se' jou' 
lan: pan: 
htou: dou: htaun daun 
tain gya: 
ein da- rei gyi: 
in: lai' 
a- kwe 
kin njha' 
a- mai' a- me: 
pja. bwe: 
sa pji' 
khi' pjaun: to lhan jei: 
taun taun i i 
ngan bja jei 
le' the: htou: 
a- khwe: a- sei' 
pai' htou: 
an: ma- ja. 
pou: kya. 
kaun: za: jei: 
jei ku: 
nau' hsoun: po 
aun mjei 
koun: tin 
a- ne' pjan 
a- than hpan: se' 
nei jin. 
mou: pje: de 
lu do 
bei' thei' 
jo: za- na 
a- ju lwe: 
tha' bin: 
wun tin ta- rei' hsan 
thi' dou 
a- njaun: pjei a- nja pjei 
a- kwe: 
tha ja zi: 
thin ju 
pjan kya: jei: 
hpou: bou: 
mja- ma na ji 
dha- bo: dhwa: 
a- kin: tha' 
dha- bo: dhei: 
hpou tou sa- te' 
nhou' kyou: 
pa- lin khan 
thei gyin pe' kyi. 
jin. kywei: 
wei nei ja. 
than wu' ta. ka' 
le' te' 
ga- za- sha' ta- ra. 
hpjou khwin: 
a- se' a- bjau' 
ba- din: bau' 
nu. ne 
ka ma- htan: 
mhu: gyi: ma' ja 
mje' nha- chi 
khwe' saun: khou' 
ba dha 
khan gyi. 
bou gyou' mhu: gyi: 
mhan bju 
lei nja 
tha- main: gyaun: 
zaun gyan: 
ga- za 
ju hsaun 
kha- ji: twin 
a- ta jei 
pjain du 
koun: ma. 
ba- du 
nga- jan. 
a- tu da- gwa. 
mou: jwa 
ta- htain de: 
sa zaun 
pan: ma. 
a- hpo 
kye' za 
la' ta- lo: 
pjou kwe: 
thu. da- ma za- ja' 
au' chei lu' 
ga- za: khoun za: 
kou dain jei: poun du 
pa- lu dou 
lai' ljo: nji htwei 
za' mjo: 
a- hsin da- za 
sa' dhi: 
chei hsou' le' ne pju. 
hsai' hsai' mjai' mjai' 
nja. da 
pji. nhi' 
a- ti. za ta. 
the' njha 
je' pan: 
wun: mjau' 
sha' sha' 
le' ja' kho 
a- kau' njan 
wun: ma- loun 
jei tha khou 
ka bjan 
ga- za: hpo 
wei hin: 
jei lhwe: bau' 
a- kyaun: thi. 
pji' si: pji' jan 
ga hta lai' 
tha- main: u: 
sou' pje: 
haun haun kyi kyi 
a- kye ta- win. 
je' gyou' 
hi ri. u' ta' pa. 
a- မြိန့် dha: 
cho: cho: mo: mo: 
oun: nhau' 
hpou lin ke: 
thwei: dhau' 
a- htain kya. 
khi' nau' kya. 
a- mje: sein: to: 
nwe chou 
a- mjin ka' 
a- shou' a- htwei: 
me: kya. 
thoun: tha' 
de' hti. 
pwe: dein: 
pin bju 
a- nau' mjau' 
nan saun 
pja. ka- tei. 
ke: kyi. 
sa- loun: 
njan kaun: 
a- lei: khou: 
to: dha: 
tha: a- mi. 
the' jin: ga- dou: 
jan za. 
da- ba' ji' 
sa gyan: 
jei loun pjou' 
chei kan 
je' kan: gyou: mwei 
oun: dhi: hsan 
kou' gyi' 
a- hsan: htwin 
thaun tin: 
in tin tin 
khun nha- than gyi hi' 
nei a: 
o da 
mai' kan: gan: 
ai' sa' sa' 
maun: le 
ga- daun: kyai' lou' 
mu ja ma ja 
che' thi. le' thi. 
ou: pou' 
ta- ne mjei 
a- ke: kha' 
a- hsei' 
nou. gyin 
ou: gyan: 
a- hsei' te' 
ma tin ga. 
htoun: dan: sin la 
than jan 
za- ga- pa- lin khan 
nga- hpe tei dei 
thein ga- nei' shwei 
nau' mein: ma. 
a: a: ja: ja: 
chin jan 
mje' dha: 
pjou mji' 
thu gye' 
pin dwe' pji' si: 
ka- lein choun 
min nhei' se' ku 
pe' le' ka- la- htain 
ein dwin: na' 
pi lo: pi nan 
le bo hsaun 
dha- bin dhe 
wu' loun do ja. 
joun: sai' 
mwei: njin: 
kye' chei kha' 
a- dei' be bau' 
chei gwin 
dha- gya: ge: 
hsei' chi: 
ta jou: 
lhwa. htaun 
le' mhan: 
mje' si. gyaun 
shou' shou' she' she' 
thi hou tha- je' zei. 
nei. za: 
joun. jin: 
mou: hswei nghe' 
win: bain 
a- si. hpau' pou: 
a- khin: a- kyin: 
ne' than 
mai' loun: gyi: 
thwei: ji gyi 
a- kyi hsai' 
pan: jai' 
je mo: 
chin khan 
jau' ko 
ta- joun: joun: 
jin gwe: za- ja' 
pa ra- mi hse ba: 
bu: thwin: 
shwei po mja. tin 
ja- min: 
mou: kya. le' hpe' 
u a- te' 
a- bi. ja sa- ka. 
an za doun: 
da- ni. 
nga- zin jain: 
le' tou le' taun: 
chi dau' 
wan: (wun:) hpo: wun: 
hsin jan 
hsei: dan: 
a- hswe: 
thi' tau' nghe' 
lai' ka 
man ma na. 
htou: wa: 
lei kin: 
wa- loun: htou: 
bu gaun 
nhan: ba' gyin 
a- hpan ta- le: le: 
a- jwe hain: 
tin: lin: 
tha- mi: 
sei' zo: 
a- lou' htou' 
sei' ma- shi. ba nhin. 
mju ni si pe 
hswe: an 
taun ta- le: 
joun bwe: 
a- twei: chu' 
pu' tai' a: 
a- hpi: 
le mjou 
thai' mjoun 
a- twin: jei: 
a- mje: dan: 
mje' si. than le 
mau' tin 
bu: zin 
htou' hpo 
lhwa gyin: 
ja du: pjou' 
a- khwin. du: gan 
a- chun a- te' 
mhe. sun: 
le' tin 
a- sa. pjou: 
nhi: khwe' 
pa- ri. ဗိုဇ် 
ga- ba pju. mou: 
mjei gyi: 
hpji' hsan: ka 
a- gyun 
mjin: gyou: 
le' kau' wu' 
pjaun: kau' 
a- hsaun mhu: 
hsin na- za bau' 
ga- bja ka- thi 
a gan du 
tha: ti' 
hsaun jwe' 
maun: te' 
kyan zi 
che ga ri 
gaun: bju zwe kyou: 
da. li 
da- mu' 
tain hpu: 
a- jei' a- mjwe' 
pou: hpa- lan 
a- tha- di. dha- da na. 
jan: ein 
nan: jin: khwei 
mje' nha- pou: tha' 
sou' sa- mjou' sa. 
a- hsa gye 
nau' hse' dwe: 
ka la. thou' 
wu' hsan ma. 
kan. lan. 
za- ga- ou: 
na: kin: 
ho: za 
htei' ka' na 
le' ban: pau' kha' 
kwe' la' 
lei lwin. 
pja: hpu' 
kya. hsin: 
lei: pin ein 
nhi' zin gyei: 
a- twin: lu na 
chei pji' le' pji' 
a- shun: hpau' 
a wei ni. ka. dou' kha. 
bjin: htan 
da- ga- de: mha. pe: 
a- thwin: pji' si: 
mjei' sou. 
thwei: ei: dha- da- wa 
a- pji. a- wa. 
hpji' mje: 
ဥပ် ba' bjan 
the pou: 
lu ga- lei: 
thi' e 
a- kyin. tan 
le' tha- ma: bau' 
an gyin: 
a- na da- ja. 
ta- ja. ja. 
shin. nga- po: 
a- kya' twei. 
pwei. oun: 
ဣဋ် hta joun 
hsun: gyi: laun: 
kyan hte' 
san gyein kyou: 
su: sai' 
sei' shou' 
gwe: pja: 
a- hpan ta- ja 
mou: gyou: dhwa: 
wa- jan: htou' 
mha' dha: 
lu nei mhu. sa- ni' 
a- je' ou: 
dha- bo: bau' 
kha: jan: gyou: 
ou' sa shin 
ဗျိုက် to: 
lhja' si' mi: 
lu bo win 
nga- hpaun jou: chau' 
htou a- kha 
a- hpwe. gyou' 
ka- la- ou' 
nei ma- hti. htain ma- hti. 
gwa. ti: gwa. tai' 
sei' hte' 
ba da. 
kha: hsi' 
wei ငှ 
ma- ni. 
thi' te' ngan: 
khoun cha. 
sa- ma- khan: 
ein dhu ein dha: 
hsun: ban: 
ba- dei tha- ri' 
ha. gwe: hta- mi 
mha' kyau' tin 
pwe: zei: 
a- chein bji. 
le' gain: 
a- hswei 
chau' loun: lhan. loun: 
a- kyan 
ယဲ့ ယဲ့ 
hpe' wun: 
hsin pou: 
da- ma. wa di 
a- thi' se' se' 
nan: njun. nan: lja 
nga- hpan gwe' 
poun kya. 
khwe' htou: khwe' lan je 
a- jin: tain: 
hpje' thin: bo: 
kan: te' thin: bo: 
a- hpja' a- ja' 
kyei: than da 
bwei: zoun. 
ka- ji. ka- hta. 
lhwa. thwa: hpo 
nei လှန်း 
pa' ma- loun: zoun 
a- ke: ma- ja. 
si. zi. pau' pau' 
jou' loun: thwin: pjin nja 
khwa lei' 
a- kyan dha- ma: 
mji hse 
jei: kwe' 
hpjei hsou 
thi' thi: wa. lan 
mje' nha- bjin 
tha: tha. me' 
khan. nja: 
mou: u: kya. 
the' nei wei: 
lhei dha- gyi: 
dou bi kya. 
je' gyaun: 
mjau' le' 
kyi: a dhi: 
mjou: jin: 
njan: hsin 
da: jei: 
tain ki 
e: maun: 
kyaun: pjei: 
hsi: shwin 
a- mwei: a- taun soun 
pa' wain: lhwa. 
sha: bju 
pa- du ba- jin 
thein: hswe: 
a- tain pin khan 
pji dhu lu du. 
si: zein shi. 
nain gan do a- lan 
ta- a: 
kha- ri' sa- ma' 
go ja hpjin 
kaun: gyi: 
a- ja dan: 
pin le le' kya: 
ein. da- lein. 
khin pou' nghe' 
to: khwei: 
a- pi: a- pain 
le' than pjaun 
shei. zaun shei. jwe' 
a- khe: dha: 
ka- lain 
nhi' thein. 
jin. ma gyi: 
nha' chi: 
a- jei wa. 
pan: goun: 
a- nhi: 
po hsan: mhwei: 
u. dhei: pau' kin: 
pou: mji mju: 
mou: nhi: 
a- lou pjei. 
pwe: htou' 
ja du: cha. 
gyi' pa- ဆမ် 
a- mhoun. 
ka' pi tan 
chei ma- kain mi. le' ma- kain mi. hpji' 
wa- ja: htou: 
mjou: zin 
min ga- la hsun: 
pau' pan: bju 
pin le 
hu dhe 
po: lo: 
hti. twei. 
swe zoun kyan: 
chwei: aun: 
ka ki 
hpa- kya. 
lu dwe' 
chei gyou' mi. 
jin ta- ma- ma. 
a- ta te' 
u: baun: 
kan: ba: jan 
saun: dan: 
a- than bja 
hsain khoun 
pjaun cho: 
je: bo 
a- ga- a- khoun 
ke' ein 
nan. gyo: hswe: 
shan: kha- mau' 
da' lai' thei 
pou: taun ma 
wu' soun 
nha- loun: jo: ga 
hsi: sa' 
ga- ja' 
kyan: doun: 
lan: mhan kan: mhan 
pjin: bjin: htan htan 
nga- mjin: 
pja. hsou gye' 
kan. gyou' pja 
tin. de 
pou' zo nan 
hpou: ei 
ta' pjei: 
paun: sa' nan 
za- na- ka. za' 
dhou. hpji' sei ga mu 
tha' ti. 
a- htu' a- mja' 
mje' khoun: mwei: 
thoun: bi: ka: 
twin: aun: 
nain gan 
nga- le' khwa 
lou' li lou' le. 
mje' nha ma- kaun: 
nji nju' 
houn: zoun: 
mjei nan: do 
hpo hsaun 
the: hte: jei thun 
kyan poun htou' 
lei' kyau' mji: 
pu: tha' 
te' zei. le' zei. 
thwe' cha ba da. 
cho: za: 
le gyain. 
wan: the' 
tha' ba. ja. nan baun: 
mei' hswei 
si: me. kan: me. 
a- chan: te' 
si: kan: shi. 
sa jei: 
ka' na 
pa- ဉှာ 
soun san: 
gaun: na: pan: gyi: 
jou: mha: gyo 
chu' cho 
pa: chaun kya. 
hpi. se' 
htau' hta: 
a- kyi a- tha 
doun: tai' 
a- tu. ma- shi. 
pji dhu bain 
shei: haun: 
jei gyan: 
hsou: nji' 
twe gyei' 
khou pja jaun 
njhi. nhain: 
se' gyou' 
moun dain 
ka- nji' 
a- me mhe. 
goun ni ei' 
kya. lu 
koun dhe lei 
pja. htan: gye' 
poun htoun: 
chi gyin: 
tha- hpjin. 
nha- chi 
hpjou' kha- ne: 
mjain kya. 
to: lai' khwei: 
a ju. 
o tou ka- jei si 
pjin khin: 
wa zou hpa- jaun: dain 
njin. ei' njin. nei 
si' hta. na. gyou' 
min: na: pau' 
pou: soun: kyu: 
a- su. shin 
ga- di. ti 
jo: sa' 
a- pjei. a- soun 
pan: dhei: khau' hswe: 
e: dhi 
twei: to: 
shwei zun njou ga- za: ni: 
o mji 
than lwin 
shai' pe' 
mjou: jei' kha 
hta- gyin. 
ei kan 
thein: htou' 
nain gan win khwin. le' mha' 
gan: hsi: 
sei' da- za. na 
hpan ti hpan tu' 
pan gya: gye' 
a- le a- pa' 
ei. ri. ja pou' 
ပြိ tha. 
san htou: 
mei: khain 
nou kou u. 
lhe: nau' mji: 
kwe daun. 
wun na. da. tha- ka. 
khun: gyi: khun: nge pjo: 
bi. la' 
to: jwa 
mei' tha- ha 
pei an. 
si' u: zi: 
mei. pjau' 
na' dein: 
chi: mun: chi gyau' 
za- li hpa: doun: 
goun khan 
thou: ga- lei: 
a- sun a- hpja: 
gau' thi: jai' 
kye' te' jei 
tha- ma- ni. shei 
ta- kou jei ta- ka ja. 
a- sei. ein 
ha. hswe: 
ma- ni. o: ga. 
le' thi: le' maun: dan: 
ti pou' 
htou' chin: kha' 
a- tou: jin: pwa: 
ဇန် na- wa ri 
htan: hso lei 
jo: gi jaun 
wi. za. jou' 
nga- lu: 
ji. the. dhe. 
khu. ta- lo: 
khwin. pei: 
a- ei' hsou: 
thwei: gyin: tha: gyin: 
hpoun: lhwan: 
hsi: gyou' 
bain: daun. 
a- kin: 
hpa- la: 
ba- hu. wou' kein: 
mhoun kou' kou' 
pa' wun: kyin 
a- ti dhi: 
da- na. tha- ha ja. 
ဂျော် gye' 
na: shan 
bju ha kyin: 
ta- chi ta- maun: san: 
hpjoun: kha- ne: 
u: zau' kywan: pjan 
nu. htwa: 
shwei lan: ngwei lan: hpau' 
a- win hsou: 
nei. gin: kyaun daun 
lhaun gyain. 
pei' baun: 
shi. ba zei 
tan me. 
hpa- je: u 
htwe' kha' kha' 
a- bjaun tai' 
lhan su' 
de wa 
a- chei 
jo: hpe' 
jan: ka: 
kyau' gyin 
sein na- bo 
a- kyan: kain 
ba bu saun 
ka- nu. ka- ma 
a- ljin: 
sa chau' jou' 
ein u: na' 
a- chou' kya. 
nja. mhwei: ban: 
u: pe. dan: 
su: za: 
mjei gwe' 
so: da- ka. 
nei zaun: 
tin hse' 
hpa: bjan 
wan: kyi: 
a- ngan: ma- ja. 
mou: jei 
nga- pi. 
pe' le' lan 
baun win 
a- lei: pju. 
sha hpwei jei: 
ba- zun le' ma- si 
kye' thein: mwei: njin: hta. 
tou shei 
lo: gyin: 
hte' လောင့် hte' le: 
hswe: gyou: cha. 
kha- jan: gyu' 
a- kyo: pei: 
nhou' je: 
wa- than ta. 
dhou. hpji' dho: gyaun. 
ဘမ်း pa- jou' hsi 
me: khwe: 
a' de 
sin gyan: 
na: ga- lo: 
ei ka da. tha- ma. 
hpi. a: 
htin ja mjin ja 
kha- baun: 
a- shoun: khan 
ba- zin: te' 
a- mi. nje: 
chein. gyein. 
a- ja' pje' 
a- ne kya. kyau' 
a- ju: a- nhan: 
da' poun 
lu. ni: ba: 
da- bje' 
mhwei nhau' 
nain lun 
poun ta- lou' 
sai' kyi. 
jou: jou: tan: dan: 
dou' kha. mja: 
ka- jo. 
goun tha' ti. 
ta' mhu: 
lein hpe hpe 
lu wu' 
shan: baun: bi 
ke' ga- ju. 
te' nji le' nji 
thwei: zoun: 
ka- lei: le' tun: lhe: 
nan me hsou: 
mhji' sou. bau' 
a- mo: hpau' 
koun pji' si: 
a- the: htei' 
le tha- ma. 
za- ni: maun nhan 
jei wun: be: 
kun kha- nau' 
wain: do dha: 
ba- loun 
da- bou: doun: 
chou: ka' 
nu: na' 
nju hta- run 
je' soun tha' 
hsei: ka- 
a- kyou: kyei: zu: 
a- ta' a- kya' 
a- tha: gin 
a: du in mhja. 
gyou hsou: win 
zei: kya. 
kou kou: 
nan nhein 
kyan: ma jei: 
dha- din: 
mi: bau' 
ta- hsin. za- ga: 
gaun: mwei hsou: mwei 
le' kya: jei jou 
a- the: lhai' u lhai' 
le' hsaun htou: 
zei: lai' 
za' za- ga: 
thu. wun na. tha ma- za' 
a- ti mhja. 
tu ju 
hswei wa: 
nain gan wun dan: 
nan nhei' 
hswei: mjei. 
nin pe: nga- hsa. 
the' ka- ji' te' 
hswei zin mjou: ze' 
jou' chi: 
mje' mhan: 
ga. gyi: 
da' sho: 
na na' 
ba- zun 
hpou: wa. jou' 
a- mjou: a- mji 
pa- le: 
kau' ti 
nga: zein: dhe 
khwe: sei' 
jwei. sha: 
kou pu 
a- mha' ma- htin 
ga- ju. na 
ja- dhei: 
be' pjaun: 
lo: ga- wu' 
a- ke: kain 
a- na: pa' 
du: dain sai' 
ba. de' chai' lai' 
tan kyi' 
dei than da- ra. ba- hu. thu. ta. 
a- thei hsou: 
a- kwe a- ka 
kyau' ji 
a- lou' thin 
a- nu. pjin nja 
taun tan ga- dou: 
mhaun gou 
hsa- ji' wain: 
a: khe: 
da' tain 
nga- hpjan 
ga- di. khan wun gye' 
mje' si. ta- mhei' 
ne nhin 
houn: houn: tau' 
lu: dwin: 
kyaun: a' 
pe: kya zan 
pa- jou' 
lain nou 
nau' hpei: dhwa: 
kan hsou: mou: mhaun kya. 
khou: dha: da- mja. 
pjaun gain: 
a- sa- chi 
a- wei' za 
ngan: tai' 
nja. ဦး jan 
bain: kaun: kyau' hpi. 
le' dwin: 
nga- sein 
nha ji 
khan te' 
nga- hpaun jou: 
jei gyaun: bja. 
the' thei lai' 
mou: khou dha: 
kyei chan: 
ja' ti gye' 
a- na jin: 
thoun: bau' 
lu mhan: ma- thi. 
a- ju wa da. 
ka- ja: jei bei' za- ga: 
jei dein 
tha- je: gyi: 
nau' kyaun: pjan 
khin htei' 
jei bjin 
a- kyan: pe' si. 
le' mou: 
thi' doun: 
kye' taun si: 
ka- le' te' te' 
u doun the: doun hpji' 
gou' chaun: chaun: 
kaun ga- lei: 
a- thoun: a- swe: kyi: 
mha' che' 
hti aun 
htan: bu: 
u: zi: 
poun zan htou' 
jwa. pou: htou: 
paun: joun: 
mi: se' 
kyei: pa 
du nji wu' soun 
pwei. bai' 
mou: gaun 
a- tha: ma 
a- kyin: htaun 
jou' soun zin 
bo gyo. 
pa- rei' nei' ban san 
a- tha- kan taun 
da- zwe' 
sa hpa' pa- rei' tha' 
mje' twin: hau' 
ma- lhan: ma- kan: 
a- sun: jau' 
min: dha: gyi: 
maun: dan 
hin: cha. 
bju rou ka- jei si 
pe ri za- gou' 
ga- ju. pju. 
lein: hsei: 
jei pjan 
thein ga ja. ja. tha. 
pain: wei 
htan: loun: pjau' 
hsa- ja lou' 
kyei: naun 
mi: tin: gou' 
au' lhu' to 
a' kwe' 
pau' ga- nan: 
ta- i. i. 
tain: chei pji mji' 
lu ja. da' 
le cha 
na lou khan khe' 
pji. tan za 
man nei gya 
mwei zein: 
je: gyou' 
a- hpou: tan 
mjei boun hpa- ja: 
pau' pan: zei: 
za- la' ta 
nga- mji' chin: 
mi: gyo 
kha- lau' hswe 
ma- thi. tha: hsou: jwa: 
se' hsan 
sin: za: 
kye' sha 
kin: lu' koun 
pa- rou gye' 
kywe: mi: 
jaun. te' 
a- hse' a- thwe 
pa- lin 
thei: bau' 
a- che' 
kyau' gyi: 
ga wun 
ze' tha' 
a- na- ma- တဂ် ga. 
a- nei ga- thin cha 
mwei: kyei: zu: 
mje' daun. 
tin kyou 
su. paun: le ja 
a- we dain 
sein jei gwe' 
lei htou: 
zei: kho 
tou: lou: tan: lan: 
kun: i' 
sa di: mhu: gyou' 
hsan bja 
shein: bji: 
le' tha- gywe 
nhin: ga in: gyi 
thi: nin. 
pji daun zu. nei. 
sa- dhe 
we' ma- lu' 
a- njhou: thou 
shei. dou: nau' hsou' 
thoun: nhoun: 
than ljin: 
sin: ti doun: 
a- the: na 
mjou: tou: mje' te' 
jan: daun. 
a- khun 
kou han pja. me 
jei wei 
na- hpa: bau' 
ka- njin zi dain 
na: zun na: hpja: gya: 
pa- la ta 
a- khan. thin 
lu sai' 
gaun: zi: gaun: kain 
jai' ja 
kha- jo kha- ju' 
mo lei' 
wu' kyin: 
ke' ga- zu: 
thau' za: 
mwei: le' mha' 
ga- bai' hsaun ta' 
njan ni njan ne' 
to: mi: 
ko ma- shin 
တျား တျား 
dha- dei ka la. 
so: da- ka. te' 
mjou: gya: 
pe: ba- zun 
the: dwin: 
za- ga- gyi: za- ga: gye 
hsei' kan: 
sai' pjou: 
ga- wun jou' 
a- khwa. 
chwe: jain hsei: 
jun kyau' 
bwe hpwe ja ja 
khun: toun. pjan 
kya ka- la' 
hsan: bja: 
chei' hswe: 
kyo: mwe: 
le zin: khan 
lu mhan: thu mhan: ma- thi. 
pa- tau' pa- ji' 
than gyou: jai' 
a- chein me. 
mou: tein tai' 
wi. thei tha- le' kha- na 
ti kein: 
a- lan pja. 
ဖျိုး ဖျိုး hpja' hpja' 
hti ra. wa da. 
pou: na- ga: 
pein: ne: bjin 
hpa- jaun: wa: 
le' pei: tha' 
hpja' lan: 
pa- khoun: dan: 
mi: htou: 
di jei 
le' kain ei' 
nau' jau'kya: 
naun kyi 
so: da- na 
ba- za' bou' 
che' kha- ne: 
pwa. bau' 
dha- di. cha' 
ta- ja- ma. gyaun: 
mje' kwe pju. 
ma- zin 
ga- za: za- ja 
hpja' than: 
u. ပေက် kha 
nei zwe 
me: chau' chau' 
bu ri. da' za' 
we' ju: na 
kyun: mjo: 
a- ti' 
a- gyi: 
a- hpou: lei: 
a- hso 
ju: thu' 
thwei: tha: kaun: 
a- the' hse' 
shwei mhau' 
a- kain a- twe 
joun: dhoun: wo: ha ra. 
laun: dan: 
boun ma- kya. pan: ma- kya. 
cho le: jo: htain 
sa pei lou' tha: 
jei goun 
pji' su 
htan: njha' 
se' to ja 
a- nau' jan: 
han lhwe: 
ဝှီး kha- ne: 
khan mjou. 
se' mhu. pjin nja 
a- ရှင့် dha: 
sa: u: za: hpja: 
tha- min ga- lei: 
ho: he: 
thei: thwe 
ja du: 
hpa: ja: 
sa: ein thau' ein 
khwe' poun: dha- ma: 
hi na- ja na. gain: 
ga- lan 
mhin jou: 
ka- thain: wun: 
pji: zi: 
ka- ji. ka- hta. mja: 
jo. ba: 
khwei: za: we' za: 
kha- ji: hsan. 
mjin: thi la 
ဂဏ် hti. 
kaun: gaun: gan: gan: 
sa: thoun: koun 
da- တွာ 
thu nain nga njhin: lou' 
za rei' ta 
chei hsou' le' ne pju. 
mja. lu 
jin kyei: 
a- hsin: tun: 
ကျို့ ကျို့ ယို့ ယို့ 
da: hte' 
ta' khin: 
a- hpjaun. 
da' tha- na. pjin nja 
nei ja' 
hta' kein: njhun: 
hswei mjou: nja ti. 
u ja: hpa: ja: 
we' u sou' 
wi. ni: shaun 
lan: mja: 
bei: htou: jin kya' na 
shei. jei: nau' jei: 
ma: ma: ja' 
nga- jou' hsi 
u. ba- dei gyan: 
le' ga- do. tin 
ka ri. 
than pjain 
sain jo 
gyi o: mei တြီ 
hswan: do tin 
pjou: htaun 
kyan hsa. 
si' tan: htou' 
a- ju gan 
pa- lin bau' 
nan: tin 
pa' du 
htu. khwe: 
lin pjo: tha: pjo: 
chaun htou: 
woun: kha- ne: 
a- hti: gyan 
a- kye a- wun: 
kyau' hsi' jou' 
hsa' hsan 
sei' than 
pei: a' 
chi: mun: 
kye' u. 
pin a' 
gan da. 
than mhjo. 
pju. za: 
mhjau' gyei 
lei njin: khan 
jou' shin min: dha: 
mou: se: 
a- ngai' hpan: 
to: kya. hse 
te' lhan: 
ga- dau' ga- hsa' hpji' 
dha- ba pa- ti. 
jein: jain 
do: hta. 
gi. mhan 
na- gan: ta- loun: mhja. ma- thi. 
ja za- wu' kaun 
kaun si' wun joun: 
mjin: wun 
in ma- ti. in ma- tan 
mou: nhaun: hse 
nei koun nei gan: 
u: htou' hsaun: 
a- si' a- gyo: 
gwa. kya. 
ta- man: hswe: 
za' pou. 
shwei hta- min: 
a- mho 
sa- hwei. 
ou: na- dou 
ne khan 
chwei: dhan 
ta- htei ja de: 
a- ke te. 
ein: e: ma- lou' 
pan: ta- mo. 
chi win u pau' 
koun ban 
goun pju 
ma- to 
lo: ka. gyaun: 
ta' hpjan. 
tha: ou' ma. 
la. kha. za: 
jun: i' 
chein gwin 
pa: mou. 
ji' dan 
a' chou' hsain 
pan: go bi 
hsin. pwa: a- ne' 
kau' nge 
a- kyo: tin: 
nga- ljin mha' se' 
jaun jan: 
mje' si. jin 
a- nu. hsei: 
ni: ba: 
naun da- ja. 
bjoun: za' gyou 
le' htei' 
ta- ja: ja. 
hta' kein: jin: 
shei. zaun 
lei htou: dan 
le' hpji' 
hsoun: shoun: 
bji' chwe: 
jaun. je: 
tha- khou: thei bo njhi. 
jan man 
kye' hsu hsi 
ka- la: 
kya' ti: mjei 
ho: gya: 
hsou jou: za- ga: 
shwei kyou 
lei: be' dhwa: 
kan: koun aun 
chou: hpau' 
htin: gwei 
lin: hswe: 
jou' njan. 
than hpou dhan ma. 
a- tou: gyi: za: 
a- mhu. lou' 
la. mje' 
joun: bjin ka- na: jau' 
a: ne: 
zei: po: 
mhjau' kein: 
a- bjin: 
ja. kyou: na' 
ma- lei: 
chi ma. 
hto: ba' thi: 
le gya 
tha: te' 
tan za 
a- the: khai' 
wa: hpaun 
taun koun: 
le' kain shi. 
pou' hsan: 
ou' o thaun: tin: 
ba- gan ဒိုလ် na 
kun ga- je' 
mo gun: htou: 
a- chin: pwa: 
hpju ga pja ga 
kho: za 
khe' ma. 
khwin. dhwa: 
pja khwe' 
lei: njhin: 
toun: maun: 
a- lou shi. 
pu tin: 
hsi kyan jei kyan gye' 
ban la' 
nou. bwei: 
a- than o: za 
kyin: mjaun: 
pja' tha: 
pan: jan 
shei: u: thin 
ne' hpjan 
mhi njan: pju. 
kyain lhain 
kain: hpju mji: 
jan htaun 
kyan: kyou' 
da- ma- du ta. 
mwei: kyu' na 
a- mu gun: 
lhan. loun: 
hpou' pu mi: tai' 
htan jin: 
mein: ma- njan 
dha- di. mu 
wa: hpa- jaun: 
shwei ba- dein 
a- ma- lei: 
hswan: do tin 
jain: pja. 
kyu' kyu' lu' lu' 
pwin. zan 
u. ဒည်း 
jein gou' thin: bo: 
pa- ra- mei 
a- nu. lo: ma. 
wan: hswe: 
thu' bja: 
kyi ka' 
sei' ku: 
than chi gyin: 
da- jin 
i' au' 
pa- lou' 
mje' nha- lou mje' nha ja. 
nhei' kye dhi: 
kyein za tai' 
kyei: le' 
ba. ba. gyi: 
cha: pou' 
ka- ma- ဇိဒ် di. 
sa- mou' 
ka- la- bju 
u. nhe: 
o di ka- loun: 
ei: ei: hsei: hsei: 
nhi' gyei' shi' hsu bwe: 
pjou: gin: kyu' 
su. zu. baun: 
ga- du: 
lun: din 
mji' ta le' hsaun 
pu. pja' 
နုံး chi. 
mje' nha- ou 
ta- gyin: 
than dei dha: 
hin: za: 
lou' za- ga: 
jaun gyi do 
lhe: jin 
sa si' 
hpan gye' se' 
ke' pa- tein 
a- the' si. 
thwei: sei: 
za- bin hsou: zei: 
than gyou kain 
kyo: pu gaun: pu 
pji: hsoun: 
wa- loun: htau' khoun 
le zei. 
na- ga: 
la. mai' je' 
kai' dan 
au' shin: 
a- mjaun 
mje' khoun: 
nau' pei' hpa- na' 
tha- mou. 
ga- bja 
than da- ra. tha. 
a- lin mi 
dha- boun thu kan 
a- sou: ja. kei' sa. 
ba- ja na. ka- ra. tha. 
maun: ma. 
pju' dan 
rwain je ti 
hsi ljo daun. 
ke. je. 
hti pau' zin 
chein se' 
kywei ban: 
pwe: za: 
a- mjou: tha- mi: 
mje' si. kwe ja na: kwe ja 
jo. ri. jo. je: 
pa- khe' dwin: a- jwe 
a- jei aun 
chau' pau' 
a- ji' kya. 
hta- njhin: gwin: 
hpa- bjou' jei na 
na' gun: 
ja. aun 
thin. tin. 
si: bwa: sha 
a- shin ma. 
lei: loun: lei: be' 
do: hpaun: 
khwei: tau' 
nhain: gyein 
lein hpe 
hswei: nwei: 
a- thou' 
nei bu လှန်း 
je' kan: kha' 
hu dha- mhja. 
kyi: ta ja 
a- kwa a- wei: 
ji njhun: gye' 
kou dwei. 
bji' tau' bji' tau' 
a- ngan. 
hsou' kain 
che' zei. le' zei. 
thou' chei tin 
htu. pi. ka 
pa: saun 
oun: lei: be' khaun 
ei kan ei: ka. 
kha' chou 
hpa- ja: a- jei do 
poun zan 
a- haun: 
pjan. mhwei: 
a- khan. dha: 
koun a- mha za 
a- tha: kya. 
ja- man zan 
mje' si. su: 
a- lhwa 
a- jou: a- jin: 
thei tha' 
nha- ma- 
au' tou ba 
ma- ni. u: bji: 
a- kyaun: pja. 
lwin ti: gaun 
nhan: ba' kyau' 
than ga do 
za- le: hto 
a- chou' hse 
za- ga: koun 
nau' ma- ja: 
mjei ka- tou' 
ka- nju' 
ba- lu: pa- le: 
nei mjin la. mjin 
hta- ka: ja: htain ka: ja: nhin. 
la. hsou' 
nhaun. nhei: 
tho: ta. 
mhjo lin. gye' 
a- njho 
do do 
lin: nou. chei: 
a- ja do 
boun dau' 
u: htei' 
ja- han: laun: 
a- htu: ta- le 
hin: lin: bjin 
mi: bou 
baun: do 
si' than mhu: 
kyou: gyou: kou' kou' 
khan. za 
khin tei' 
hsei' sa 
nhi: khau' hpja 
shwei jei: 
bei: hti. 
chaun: ngin 
pa' tou' 
hpoun: kwe 
gya: bja' 
me' gin 
za- ga: sa. mja: 
a- jou: a- sin 
mu. ni. 
a- htou' 
dha- bjei ban: 
mei: jou: 
lhja' si' da' 
sa: ချဉ့် pjan 
du: chaun 
a- twin: wun 
kei' sa. wei' za- 
si: pain 
bei: ti: 
a- bi. njin 
chei soun pji' win 
sei. za' kyaun: lan: gyin: 
nga- je: ou: 
au' zo nan 
pa- ji' 
dha- ba wa. 
hpau' ei' 
le' saun. 
gwan: ka' 
ba- hou zi 
le' shaun 
ka- tou' kyin: 
ja dhi se' 
choun: pwe: cha. ngou 
nei. swe: 
kyo: khain: 
le' hwei. 
ja' hsain: 
mou: gya. 
je' ma- shou 
nan: hsan 
lei' ta 
ou' ta- ja than 
jei si' 
pe: gyi: khun tun. 
hsin: je: 
chei njaun: le' hsan. 
a ka 
njin: hsan 
mi: gou: kywe' shau' 
da: jou: 
ba- wa. haun: 
da' khan 
than da khe: 
bwe. lun thin dan: 
za- ga- mja: 
gya' mein njou 
a- lin: 
poun khain: 
tha- hau' tha- he' 
a- hsou: kya. 
lu mjou: gwe: 
mho aun 
pji' pji' kha ga 
kan. lan. cha. 
chein hsa. 
chu: pai' hsan 
a- mein. za 
ma- chu' 
a- pjaun 
a- lin: bau' 
sei' bjei le' pjau' 
mjin: ma. 
mji: du: jou: 
je' kan je' kan 
ta- ja: gwin 
jwa tan: shei 
thin: dhi: 
gan ဓဗ် ba- 
bu: mhjo: 
nhan: bju: 
ga- dou. zei' 
sei' lai' man pa 
lei mwei. ja 
san: pwin. 
nain ja za: 
ni ta je: 
pji jei: pji ja 
kou du: 
lu chi' lu khin po: 
ba- jou kei' 
lu gyi: soun ja 
khaun jan: 
htwei dwei le le 
le' ban: 
a- chein bain: 
nha mhou' 
o: ga tha. lo: ka. 
khou nan: chou: 
a- tei' 
wun zaun 
htin mjin 
maun: kyau' 
hsan gyin ta ja 
mu mhan 
kau' lhain: 
zei: ga- za: 
hsin: pu. 
ma na. wi 
bjaun kya. 
nha- pa: zoun 
htou' hsaun 
kyou: kain 
hpaun: kan 
lu wu' le: 
hpoun: do gyi: 
hsaun: mji: na 
a- jai' a- ja 
mjin zu tha- ka. 
ne lu. 
mjei taun mhjau' 
na' nou: la. 
mi: kwin: 
a- le 
lhu bwe wu' htu. 
thin: bo: hsa: bou' 
ma- nou' tha. bei da. 
zun: gyi' oun: 
ka ma. 
hsu: taun 
ba- zun hsi 
a: te' 
tun. lei' 
da- bou: gyi: 
ka- na- sou: 
a- ku 
a- kha gya: a- mjau' 
moun ji' 
pwe: ja. 
tha' pa ja. hpji' 
kha- naun: 
tha- nge do jou' 
ma- hsi' hsi 
a- lei: gyein 
tha wa- ka. 
an saun 
nau' hta. 
a- ra- ha' ta- me' 
woun: woun: dain: dain: 
bwa: bwa: 
nei hti: hsaun: 
a- gyo: mhjin 
hpaun: hpjin: 
je: njun. 
a mei dei' 
mau' ju 
bein: chi: 
mwei ba- da: 
kyi gyi shwin shwin 
ta- oun nwei: nwei: 
a- lan jai' 
ja' thi. jwa thi. 
mou: the' moun dain: 
na- dha 
tho: ka: 
than taun 
nei bu sa' kha: 
hpan ba- dain: 
mje' sa. mje' na. 
nga. shin 
a- kyin. pa 
jau'kya: dhu 
oun: hto: ba' 
kyaun: hta: 
a tei' sei' wain: 
mje' wu' 
chou tha 
hpin da- kywa. gywa. hpji' 
jei gyou koun 
lo: ba. 
za- ga: nha- khwa. pjo: 
ba dha pjan 
a- kha. za: win 
a- ke: 
twe' si' 
pei' thin: kha' 
nhou' mei: gun: 
hpe jan: 
ja za- wu' thin. 
kyi pja jaun 
a ka tha. pwin. 
na- gye gaun 
lei jin gwin: 
... jou: ... zin 
ka' hpou ka' ma. 
a- jaun tin 
kan bain 
thi' si: kain 
da- gun dain 
khwin. lhu' 
dha- da bau' 
hsin ka' le 
a- mu a- ju 
a- pjo: a- ho: 
koun gan: 
ba- gan 
jei zein kywe: 
mje' twin: kya. 
jei mha' 
chi ba- mje' 
si: dha: 
hin: gywei: 
a- gyain. dha: 
ba- lu: gyein: 
hsou: jwa: 
kha- na. ban: 
mein: ma- dein: 
jou' shi. 
zin: sa: khan: win 
tain dan: 
goun ji 
a- kyaun: sha 
za- be 
khou: kyi. 
mi: a ma. gan 
a- khe: ma- kyei 
le jain: 
a- ngha: 
kyu' hsa' hsa' 
u. bou' 
da-ra' zin 
hse' khan 
na' ka- do 
than jou' bji: 
htei' htei' kye: 
than ke' ga- zu: 
wa- zi kan 
sei' hsaun 
a- ke da. mi 
dha- di. mei. 
pe: di pin bau' 
pju. lou' 
koun chau' 
ma- chi' u. 
ji: di: ja: ta: 
a- mu: dha- ma: 
a- mhja. pei: 
da- ma- u: cha. mjei 
koun nga. 
zei: kaun: 
pe pe ne ne 
zei: kyou 
a- kyaun: ma- lha. 
hsa- ne 
than da pjan 
thwa: tu. 
wa: pa' 
dha- din: mhwei: 
mi: win mi: htwe' 
chwei: thei' 
hpa' la' kya. 
pjan dan: khan 
a- tou. a- htaun 
sa- chin. bwe 
thein hpjin: 
pji. kya' 
kyei: ni 
a- thoun: sa jei: 
a- jaun zaun 
nan ba' koun aun 
te' te' zin 
ti htaun 
moun. bain: daun. 
lei' kyau' mji: 
ga- di. thi' sa pju. bwe: 
tha: je: ta- rei' hsan 
tin ba: hsoun 
kei ti. ka ti. lou' 
mou' hsou: 
le' khou' le' wa: ti: 
hsou: wa: 
a- ni: nhin. a- mja: 
kyau' mje' ja- da- na 
me: hsan da. ne 
le' oun dha: 
ba- da na. kya. 
tau' ja' 
kha- ji: lun 
sain: nhin 
ta- aun. ta- na: 
na- than dhi: 
sha chi 
lu lu' 
a- mi: sa: hpe' gaun: za: hpe' 
joun: twin: za 
su: zu: jwa: jwa: 
ma- ga- da. ba dha 
kha- jei pwin. 
kya thin gan: 
njhun kya: gye' 
le' sa. gyi: 
dhou. ga- lau' 
hpe' le: ta- kin: 
lwan: hsu' 
tu ma. 
nga- ne: 
a- mje: a- swe: 
pji bu. 
a- me min: 
tha: dhe a- mei 
bein du. 
lu dhwe' 
jo. ni: 
a- nou' a- sou' 
me: ne 
nje' ညော 
nei. le za 
hpoun: zou: to: 
le' lun 
pein njin: 
kha- ju. tou' 
toun doun jin jin 
hpjan. bju: 
a- than 
lwe gu 
mo: ha. 
ta lu. za. 
tha- ရဇ် စျာယ် 
hswei ni: mjou: sa' 
a- hpjo 
kye' khu' 
a- ja a- htaun 
ma- tha- ti 
kyei: mi: hpou 
u. pa- pa' 
pa' ta- la: 
u haun: laun: hpji' 
khau' khu. din 
tha: gyi: nga: gyi: 
jaun: jin 
than ga zin 
zwe: hsu. 
nge zin taun kyei: 
a- hsaun a- jwe' 
a- khou: 
pan: le dain 
a- she' khwe: 
le' pja' 
kou lu' le' lu' 
au' hswe 
lu gyi: mi. ba. 
a- loun: a- hpan 
le' jei' pja. 
aun. e: 
mjei khan 
wa: pou: mje' hsan gye 
jwe du dan: du 
ka gwe jei: 
na mji hwe' 
သျှီ lin 
a- thoun: kya. 
jo: ja 
sou. da- ga: pei' 
lhe: than 
hpu: za hsoun 
kya: gya: ja: ja: 
ou: dan 
mhjoun: paun: le: 
a- kyi. 
a- hti. 
ma- gan: 
tha- ra- na- goun thoun: ba: 
na: pji jou 
di mou ka- jei si 
poun zan tou' 
ma- ha bju ha 
le' an thei 
mo: mu ha. da. tha- ka. 
go: za gyou 
ta- zei. da- zaun: 
thi ta. 
hsou: tei 
tha du. kho 
ou' hpa- na' 
na mji ta' 
tha- he: 
pa- li si. chau' che' 
hsa' goun: 
po: dho: 
lou da- ja. 
kou bain 
na- ban: 
a- ljin a- mjan 
lin: we' 
te' ka- bei da. 
ngan: mwei 
ta pa' gwin: 
a- kwe: a- sha. 
chi gyin: lein 
a- tin. je: 
ja za- wu' 
mje' si. shan 
pjau' kwe 
be: daun 
htu: hsan: 
chin dhei. 
wa dha- na ba 
kun: dhi: bin 
jin: ba: 
lei gyou thwei: 
na- bu: lein 
lou' kwe' 
tha- ra- na- goun tin 
a- jei: hta: 
be' lai' 
lin: da. mhain mhain 
thi' htwin: ba- gyi 
zi za- wa 
hsain: nau' hta. 
poun wu' htu. 
ma- jan: jaun 
mjin. mja' 
njein: ei: 
pa- hta- ma- nge 
a- soun a- soun 
joun: kan 
a- hsin. 
nha- khan: kwe: 
wa ba' 
ka- lun taun 
da- bje' si: 
kha- ji: gyan: 
si' ta- lau' 
a- jou a- thei pei: 
se: ze: 
lei than 
dha- bu' 
a- kho a- wo 
nga- man: swe 
da- gau' kwei: 
twin khoun 
a- mjin gye 
thei gya ga- na. 
lan cha: 
ka- li. jou' 
je' hte 
u soun the: zoun 
ba- lu: zwe 
a- ju: a- mai' 
kau' nhou' 
hpan mi: ein 
hpji' sin 
se' kya. 
u kyaun gyaun hpji' 
ba- nan: 
mjei we ma- kya. 
ou' sa ju: 
njhou hsain 
hta- jei 
kou dain kou kya' 
kan kaun: htau' ma- lou. 
pa- ti. pe' kha. 
zei: baun gyou: 
ou: khwe: 
tha- je' pa- ni 
hsan kwe: 
gau' gwin: 
da- ha' tha. gain: 
win koun 
daun sain: 
ta wei 
dhou. hpji' lhjin 
mhan khwe' 
mjau' jau' ma. 
hpoun: gyi: kyaun: 
hpan dou. dan: 
ma- nhi' 
na: sai' 
mjou. do wun 
da ja- ka ma. 
jei gyou 
le' jan: le' hsa. 
tha: lhi: da: 
jei dwin: 
mi: boun bwe: 
a- ju: chi: pan: 
lei gyin 
mjou. khan 
hpin mje: 
moun. thi' ta 
wa da' 
a- loun: zei: 
o. nha- loun: na 
ba ja. zei 
nan nge bain: 
wa- thi bo 
a- me 
mjin wa: 
dha- din: gaun: zin 
kya: ma. 
ka- ne' ga- dan 
nou. njha 
lei: gin: 
hti. ba: 
an hswe: 
pa' shau' 
tha- ma: jou: kya. 
le' khe' 
jei chou: zei' 
kin: mi: gau' 
bou' da. tha dha- na 
shu. ti ti 
kyin hpe' 
အဇ် စျတ် ta. 
an hsoun: 
jou zi: 
ta- mjin: kha' 
than shei 
je: tin: 
than dei pa 
pai' da- min: 
ga- za: 
na ga- ri 
choun khou tai' 
sei' ku: sei' than: 
poun: jei taun za 
za- bu pa- ni 
man: mhou' 
hsa la ei' 
kha le 
hpe: thei 
ein daun pju. 
chi gyo le' gyo 
cho le: 
ta- kha de: 
lhei gyi: htou: jou: jou: 
khe' khe: 
ka- ti. kyaun daun 
sa- tu. ma- ha ji' 
jin: nhi: mhjou' nhan 
jan: zein: 
ka- htein 
hpa- lan 
mjou: ze' 
goun pa- ka tha- na. 
chin: ta. 
da- ga: 
njou: njou: njei' njei' 
a- pjou a- jwe 
a- sun: a- sa. 
the' ka- la' 
ja. tha. sa pei 
da- bwe: dou: 
hsun: khan pin. 
mi: ge: pja boun: 
pan: pu. 
kwa ha. gye' 
sei' da- za. nan 
je: ta' hpwe. 
a bo 
da' bu: 
jei bjin nji mjin: 
jei htou' mjaun: 
jei mhoun jei mhwa: 
ta lhu' 
lo: kyan: 
a- mhu. dan: sa ou' 
njan do 
chou chin 
a- mhu. twe: dein: 
hpjei: bjei: 
lai' pjei: 
tin: htein 
a- lein ma thoun: 
loun: bau' 
a- chou' a- lou' 
a- mei: a- mjan: 
lwan: hpja: lwan: na kya. 
pju. mu 
lu. je' 
mje' mhaun kyou' 
kha- ji: kyun 
poun zan khwe' 
mje' twin: chaun 
ga- ba lo: ka. 
shun. nun 
au' ကျို့ 
hpa- jaun: pa- hsou: 
jei zi 
tha: gaun 
da- ba' shou 
sein ni mjin: dhwa: 
a- khou: tha' 
lou' kain 
ou' khoun 
thei: ban: 
pwin. thi' sa. 
tha- min thwei: 
mje' si. pja 
so ga: 
hpa- ja: pja. 
sei lhu' 
ngan pja. bja. 
me: kyou' 
a- jou: khan 
thi' htei: 
tai' jei jin 
ni: mja: ma- hsou 
hsi zei: 
kye' jou: htou: 
ei ga- mou' oun: 
nwan: ji. 
oun: mhou' ta- jo: 
a- the: gyo 
tha' da. ni. ke 
nwa: sha gyi: 
si' mji: 
hsan mhoun. 
jaun: we hpau' ka: 
a- chi: za- ga: 
tan zi: 
tha- chin: dha: 
te: tha- lei' hswe 
a- mha' ja. 
pji. nhe' 
loun: loun: khe: ge: 
kyun: khau' nwe 
sa- jwei: 
lin ni min 
mje' ji' 
shwin shwin pjoun: pjoun: 
khan. nja: 
a- tha: hsaun 
jou: jou: 
ei' hsaun 
khou ka' 
u: hsaun njhun kya: jei: mhu: 
thwei: te' 
njhin: loun: 
hpwe. gyou: 
na- tha- ni 
pjei njein: 
ta- nei. ka. 
koun zi pja. bwe: 
nei ja cha. 
jei ga- do. 
poun: kwe 
wu' le 
a- lein a- nja 
bjoun: za: bjin: za: 
nhou' kyin: 
a- mwei: 
ka- lo tou' 
pja: jei 
pja thei' mou: 
da- la- ho: 
ma- a: 
ti bi 
sa mu gyan: 
thwei: si' 
nga- bjan 
ka- lei: pje' 
che' chin: le' ngin: 
a- mhu. lou' 
chin twe 
lu soun te' zoun 
si' pjei: 
pou' ba. na- mei' 
le' bjin: 
te' ka- zi: 
khwei: hswe: 
pjou' pjou' pjoun: 
si' zi: 
mjou. ja nin: 
njein ဆိမ် 
ja za- da ni 
ei ga- mu 
hpau' the zei: 
wi. pa' ti. ta- ja: 
kyi. pjo shu. pjo 
min: dha: gyan: 
pu: baun: 
ou' za: 
kha: na 
e' si' 
ja' gyi: dha: 
kyi. chwe: 
hsun: thu' 
dha- bei' 
jei wei koun: dan: 
a- tan: a- sa: 
ba bu 
kye' paun zei: 
ka- li ka- ma lou' 
nhaun: da- gu: 
pan: dou' 
na- bin: dain 
mwei: za jin: 
pi pi pjin bjin 
mi: pu 
hsou: thwan: lu nge 
kye' mi. 
twei. kyoun 
pin. the' shu 
ta' htein: chou' 
wan: ja: mhau' 
hsaun: khou 
thin: bain 
ja' zun jwa na: 
pein chi. 
pu' su: 
jou jwin: 
nga- mjin: ou' hpa: 
zei: hswe: 
hi' dain 
nga- mhja: 
gan da- ma 
in pjei. 
thu ta- khun: nga ta- khun: 
ma- htei 
sein: za: u. 
daun gya sain: 
pa' ma. 
pjin dha lei' 
wun le' 
hswe: ngin a: 
hsin chei: doun: hsa' pja 
jei ja 
wan: ne: pe' le' 
pa- ma da. 
ဂစ် lhei 
na- mu: na- htain: 
a- sa jei za 
ju' na: 
shu: tai' 
hpjan hpjei 
thu. min ga- la. du. min ga- la. 
pwe: wain: 
kya bju 
nge dhan pa 
nge zei' 
ka ယိန် da- rei 
ban: tin 
a- dei' be shi. 
dain khan 
pa- htwei: 
lu loun: pja. 
a- laun: a- sa: 
pa- ti. zi wa. hsei: 
lei: tin 
lei tha- la' 
pou' အဲ့ အဲ့ 
nain kwe' 
a- thi. 
kan: jou: dan: 
tha- po. 
ta- me kaun: 
nga- gyin: kwe' 
a- mhoun a- mhwa: 
a- sein: gyo 
sun gou' 
အုန် au' 
mi: pja. dai' 
sei' pain: hpja' 
lu' la' jei: mo gun: win 
dha- din: zoun 
chou htaun 
the' ka- ji' shei 
sa- ne mjei 
lei zan 
a- mha' 
kye' dha: 
hsi: aun. 
bu: dhi: gyo 
le' pje' 
oun: nhau' shin: 
chou ti lu: 
le' hpji' ti: 
a- kha tha- ma- ja. 
jan zwe nhin. ငေါ ငေါ 
chi zi' pwe: 
a- tain a- to: 
kyei: zu: gan: 
hpau' su: 
a- ne hta. 
jo: ha- ni 
ka- mau' ga- ma. 
ka- ma gyi 
a- na jin: 
le' gyo: tin: 
le' wa: zaun: 
koun bou' 
da- be. 
than gyi: 
ma tin ga- mho 
jau' chou 
a- ja' tha: 
a- kwe' sha 
me: kyo: 
a- jei' a- jaun 
je' tou thin dan: 
mje' nha- kye' 
chun: ma. 
pai' wan: pu 
lu dha: 
ba- htwei: 
lu mwe: 
nei bu khan dhi: 
mjei nji hta' 
na- ju ba- dei tha. 
a- hpou: ou 
na mji khan 
thu do thu mja' 
hpjei. bju: 
e. jei' tha 
ei' boun: 
thin tha- ka. jai' 
wi. ni: dou 
ljo zwa 
ga- dwin: shin: 
a- ngan: 
le' kyin. 
shei: ba- wa. 
chin zi 
pjaun shu' shu' 
poun ဏေး ma. 
man: jei ngan: ji 
a- ja 
na- bin: 
win jou: sun: dei tha. 
pa: thain: mwei: 
ze tau' 
lain sin khan 
thi: than. 
ei ga- bai' 
toun: ti. di. 
jan: jo 
ze jei: ta- jei: kou: jei: ta- ja 
twe' hsa. 
kha- le gaun 
sun je: 
pin mhe. 
mje' nha bje' 
na' tha- mi: kan: ba: 
a- mhin 
po htwe' 
pan: ou: 
wa: pou: 
kin: boun: 
thei na gaun 
ga- do. hsun: 
ta- ja: win 
joun bain 
hpa: ku: 
sun taun hswe: 
ou: htein: se' 
kyei: zu: shin 
